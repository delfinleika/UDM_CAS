import LikertScale from '@/app/components/LikertScale'
import { Metadata } from 'next';
import React from 'react'

export const metadata: Metadata = {
  title: "Evaluate",
};

export default function page() {
  return (
    <div>
      <LikertScale />
    </div>
  )
}
