import NewAnnouncementForm from '@/app/components/NewAnnouncementForm'
import { Metadata } from 'next';
import React from 'react'

export const metadata: Metadata = {
  title: "Announcement",
};

const page = () => {
  return (
    <div className='flex my-auto min-h-screen'>
        <NewAnnouncementForm/>
    </div>
  )
}

export default page