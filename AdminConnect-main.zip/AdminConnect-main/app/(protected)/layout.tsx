import type { Metadata } from "next";
import { cookies } from "next/headers"
import Header from "../components/Header";
import { SidebarProvider, SidebarTrigger } from "@/components/ui/sidebar";
import SidebarNav from "../components/SidebarNav";
import Chatbot from "../components/Chatbox";

export const metadata: Metadata = {
  title: "Admin Connect",
  description: "Connecting Public Administration Information by Universidad de Manila",
};

export default async function  RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  const cookieStore = await cookies()
 const defaultOpen = cookieStore.get("sidebar:state")?.value === "true"
  return (
      <main className="relative mx-auto w-full">
        <Header />
        <SidebarProvider defaultOpen={defaultOpen} className="relative">
          <SidebarNav />
            <SidebarTrigger className="top-1 left-1 max-md:fixed bg-blue-100 hover:opacity-80 mx-5 mt-5 rounded-lg w-10 h-10" />
            <main className="mx-auto w-full">
              {children}
            </main>
        </SidebarProvider>
        <Chatbot />
      </main>
  );
}
