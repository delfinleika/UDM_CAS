import { Metadata } from "next";
import Image from "next/image";
import React from "react";

export const metadata: Metadata = {
  title: 'Officers',
}

export const StudentCouncil = () => {
  const officers = [
    { name: "Rosalie M. Catu", position: "Adviser" },
    { name: "John Lloyd Senados", position: "President" },
    { name: "Danica Jane C. Sison", position: "Vice-President Internal" },
    { name: "Dr. Emily White", position: "Research Director" },
    { name: "Llana Loren A. Tiro", position: "Vice-President External" },
    { name: "Samantha Andrea V. Nahlen", position: "Secretary" },
    { name: "Penelope Hope Talamente", position: "Assistant Secretary" },
    { name: "Lyka Jane L. Mangahas", position: "Treasurer" },
    { name: "Kathleen Julianne P. Sales", position: "Assistant Treasurer" },
    { name: "Angelene P. Alejano", position: "Auditor" },
    { name: "Rovy Ian Flores", position: "P.R.O" },
    { name: "Ma. Kyla Eunice Jose", position: "4th Year Representative" },
    { name: "Kim Andrea Nicole Romeroso", position: "3rd Year Representative" },
    { name: "Pammela Santos", position: "2nd Year Representative" },
    { name: "Sophia Lorraine Nicolas", position: "1st Year Representative" },
  ];

  return (
    <div className="min-h-screen">
      <div className="mx-auto px-20 py-20">
        <h1 className="mb-6 font-bold text-3xl text-center title">
          Public Administration Student Council
        </h1>
        <div className="gap-4 grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3">
          {officers.map((officer, index) => (
            <div
              key={index}
              className="items-center gap-5 bg-white shadow hover:shadow-lg px-5 py-2 rounded-lg transform transition-transform cursor-pointer hover:scale-105 hstack"
            >
              <Image src="/logo.png" alt="Logo" width={50} height={50}  />
              <div className="items-center w-full text-center vstack">
                <h2 className="font-semibold text-xl">{officer.name}</h2>
                <p className="text-gray-600">{officer.position}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default StudentCouncil;
