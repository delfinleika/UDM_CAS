import { Metadata } from 'next';
import React from 'react'

export const metadata: Metadata = {
    title: "About us",
  };

export default function page() {
  return (
    <div>
        <div className="mx-auto px-4 py-10 container">
        <h1 className="mb-8 font-bold text-4xl text-center title">About Us</h1>

        <div className="bg-white shadow-md mb-10 p-6 rounded-lg">
            <h2 className="mb-4 font-semibold text-2xl">Mission</h2>
            <p className="mb-4 text-gray-700 text-lg">
                Our mission is to provide high-quality education and training in public administration, fostering critical thinking, leadership skills, and ethical governance among our students.
            </p>

            <h2 className="mb-4 font-semibold text-2xl">Vision</h2>
            <p className="mb-4 text-gray-700 text-lg">
                We envision a future where our graduates lead with integrity, contributing to the development of effective and accountable public institutions that serve the community and society as a whole.
            </p>

            <h2 className="mb-4 font-semibold text-2xl">Values</h2>
            <ul className="text-gray-700 text-lg list-disc list-inside">
                <li><strong>Integrity:</strong> We uphold the highest ethical standards in our academic and professional practices.</li>
                <li><strong>Excellence:</strong> We strive for excellence in teaching, research, and community engagement.</li>
                <li><strong>Inclusivity:</strong> We promote an inclusive learning environment that values diversity and encourages participation from all students.</li>
                <li><strong>Service:</strong> We are committed to serving our community through outreach, partnerships, and civic engagement.</li>
            </ul>
        </div>
    </div>
    </div>
  )
}
