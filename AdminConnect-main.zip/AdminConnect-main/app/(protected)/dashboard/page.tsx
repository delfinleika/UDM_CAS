import { BarChartTeachers } from '@/app/components/BarChartTeachers'
import ListEvaluations from '@/app/components/ListEvaluations'
import { DataTableDemo } from '@/app/components/TableListEvaluated'
import { Metadata } from 'next';
import React from 'react'

export const metadata: Metadata = {
  title: "Dashboard",
};

export default function page() {
  return (
    <div className='mx-auto py-10 max-w-screen-xl'>
      <div className='gap-5 grid md:grid-cols-3'>
       <div className='flex col-span-1 h-full'>
        <ListEvaluations/>
       </div>
       <div className='col-span-2'>
        <BarChartTeachers />
       </div>
      </div>
        <DataTableDemo />
    </div>
  )
}
