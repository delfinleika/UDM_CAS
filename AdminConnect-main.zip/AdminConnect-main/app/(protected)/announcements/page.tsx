import { Metadata } from "next";
import React from "react";
import Image from 'next/image';
import ListAnnouncements from "@/app/components/ListAnnouncements";

export const metadata: Metadata = {
  title: "Announcements",
};

const Announcements = () => {

  return (
    <div className="py-10 min-h-screen">
      <div className="mx-auto px-6 container">
        <h2 className="mb-8 font-bold text-4xl text-center text-gray-800 title">Announcements</h2>
        <ListAnnouncements />
      </div>
    </div>
  );
};

export default Announcements;
