import React from "react";
import { Metadata } from "next";

export const metadata: Metadata = {
  title: 'Contact',
}

export const ContactUs = () => {
  return (
    <div className="min-h-screen">
      <div className="mx-auto px-4 py-10 container">
        <h1 className="mb-6 font-bold text-4xl text-center title">
          Contact Us
        </h1>
        <p className="mb-8 text-center text-lg">
          If you have any questions or need assistance, feel free to reach out to us using the contact information below:
        </p>

        <div className="bg-white shadow-md mb-10 p-6 rounded-lg">
          <h2 className="mb-4 font-semibold text-2xl">Contact Information</h2>
          <p className="mb-2 text-lg">
            <strong>Email:</strong>{" "}
            <a href="mailto:udm.yapak@gmail.com" className="text-blue-500 hover:underline">
              udm.yapak@gmail.com
            </a>
          </p>
          <p className="mb-2 text-lg">
            <strong>Phone:</strong> +1 (123) 456-7890
          </p>
          <p className="mb-2 text-lg">
            <strong>Office Hours:</strong> Monday to Friday, 9 AM to 5 PM
          </p>
          <p className="mb-2 text-lg">
            <strong>Address:</strong> 659-A Cecilia Muñoz St, Ermita, Manila, 1000 Metro Manila
          </p>
        </div>
      </div>
    </div>
  );
};

export default ContactUs;
