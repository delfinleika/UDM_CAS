import { SidebarProvider, SidebarTrigger } from "@/components/ui/sidebar";
import type { Metadata } from "next";
import "./globals.css";
import { cookies } from "next/headers"
import SidebarNav from "./components/SidebarNav";
import Header from "./components/Header";

export const metadata: Metadata = {
  title: "Admin Connect",
  description: "Connecting Public Administration Information by Universidad de Manila",
};

export default async function  RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  const cookieStore = await cookies()
 const defaultOpen = cookieStore.get("sidebar:state")?.value === "true"
  return (
    <html lang="en">
        <body className="relative flex flex-col">
            <main className="mx-auto w-full min-h-screen">
              {children}
            </main>
        </body>
    </html>
  );
}
