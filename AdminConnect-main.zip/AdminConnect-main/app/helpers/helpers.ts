import { redirect } from 'next/navigation';

export interface UserResponse {
  UserId: string;
  Fname: string;
  Lname: string;
  Role: string;
  YearLevel?: string;
  Block?: string;
}

  // Helper to extract and validate user response
  export const getUserResponse = (): UserResponse => {
    const userData = localStorage.getItem('userData');
    if (!userData) {
        // redirect('/sign-in');
        return { UserId: '', Fname: '', Lname: '', Role: '', Block: '', YearLevel: '' };
    }
  
    try {
      const [ UserId, Fname, Lname, Role, Block, YearLevel] = userData.split('-');
      if (UserId && Fname && Lname && Role && Block && YearLevel) {
        return { UserId, Fname, Lname, Role, Block, YearLevel };
      }
    } catch (error) {
      console.error('Error parsing user data from localStorage', error);
    }
  
    return {UserId: '', Fname: '', Lname: '', Role: '', Block: '', YearLevel: '' }; 
  };
  