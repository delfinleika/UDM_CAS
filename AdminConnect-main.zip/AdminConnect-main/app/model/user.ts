// User.ts
export interface User {
    id?: number; // Unique identifier for the user
    userId?: string; // User's unique identifier string
    imgURL?: string; // Optional field for profile image URL
    fname?: string; // User's first name
    lname?: string; // User's last name
    gender?: string; // Optional: User's gender
    address?: string; // Optional: User's address
    phone?: string; // Optional: User's phone number
    emailAddress?: string; // Required: User's email
    password?: string; // Required: User's password (hashed in production)
    role?: 'Admin' | 'Student' | 'Guest'; // User role, restricted to certain values
    createdAt?: string; // Date of account creation
  }
  