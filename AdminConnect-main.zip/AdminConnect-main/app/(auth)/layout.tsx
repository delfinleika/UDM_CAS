import type { Metadata } from "next";
import { cookies } from "next/headers"

export const metadata: Metadata = {
  title: "Admin Connect",
  description: "Connecting Public Administration Information by Universidad de Manila",
};

export default async function  RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  const cookieStore = await cookies()
 const defaultOpen = cookieStore.get("sidebar:state")?.value === "true"
  return (
      <main className="mx-auto w-full min-h-screen">
          <div>
            {children} 
          </div>
      </main>
  );
}
