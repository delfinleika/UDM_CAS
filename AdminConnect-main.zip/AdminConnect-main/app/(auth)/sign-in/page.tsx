import SignInForm from '@/app/components/SignInForm'
import { Metadata } from 'next';
import React from 'react'

export const metadata: Metadata = {
  title: "Sign in",
};

export default function page() {
  return (
    <div className='flex my-auto min-h-screen'>
      <SignInForm/>
    </div>
  )
}
