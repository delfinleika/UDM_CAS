import SignUpForm from '@/app/components/SignUpForm'
import { Metadata } from 'next';
import React from 'react'

export const metadata: Metadata = {
  title: "Sign up",
};

export default function page() {
  return (
    <div className='flex my-auto min-h-screen'>      
      <SignUpForm/>
    </div>
  )
}
