'use client';
import React, { useEffect, useState } from 'react';

interface User {
  Id: number;
  Fname: string;
  Lname: string;
}

// Functional component to fetch and display users
export const ListUsers: React.FC = () => {
  const [users, setUsers] = useState<User[]>([]); 
  const [error, setError] = useState<string | null>(null); 
  const [isLoading, setIsLoading] = useState<boolean>(true);

  useEffect(() => {
    const fetchUsers = async () => {
      try {
        const response = await fetch('http://localhost:3001/users');

        console.log(response)
        if (!response.ok) {
          throw new Error(`Failed to fetch users: ${response.statusText}`);
        }

        const data: User[] = await response.json();
        console.log(data);

        
        setUsers(data); 
      } catch (err) {
        setError((err as Error).message);
        console.error('Error fetching users:', err);
      } finally {
        setIsLoading(false);
      }
    };

    fetchUsers(); 
  }, []); 
  if (isLoading) return <p>Loading users...</p>;

  if (error) return <p className="text-red-500">Error: {error}</p>;

  return (
    <div className="bg-gray-100 p-5 rounded-lg">
      <h1 className="mb-4 font-bold text-lg">User List</h1>
      <ul>
        {users.map((user) => (
          <li key={user.Id} className="mb-2">
            {user.Fname} {user.Lname}
          </li>
        ))}
      </ul>
    </div>
  );
};

export default ListUsers;
