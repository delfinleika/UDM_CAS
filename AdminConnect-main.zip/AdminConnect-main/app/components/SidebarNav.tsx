'use client';
import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
} from '@/components/ui/sidebar';
import {
  Bell,
  Home,
  LayoutDashboard,
  LogOutIcon,
  Mail,
  SearchSlash,
  Speaker,
  UserRound
} from 'lucide-react';
import Image from 'next/image';
import { usePathname, useRouter } from 'next/navigation';
import { useEffect, useState } from 'react';
import { getUserResponse, UserResponse } from '../helpers/helpers';

const commonItems = [
  { title: 'Home', url: '/home', icon: Home },
  { title: 'Announcements', url: '/announcements', icon: Bell },
  { title: 'Officers', url: '/officers', icon: UserRound },
  { title: 'Contact', url: '/contact', icon: Mail },
  { title: 'About Us', url: '/about-us', icon: SearchSlash },
];

const adminItems = [
  { title: 'Admin Dashboard', url: '/dashboard', icon: LayoutDashboard },
  { title: 'New Announcement', url: '/new-announcement', icon: Speaker },
];

const studentItems = [
  { title: 'Evaluate', url: '/evaluate', icon: LayoutDashboard },
];

export default function SidebarNav() {
  const router = useRouter();
  const currentPath = usePathname();

  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [currentUser, setCurrentUser] = useState<UserResponse | null>(null);

  useEffect(() => {
    const userResponse = getUserResponse();
    if (userResponse) {
      setCurrentUser(userResponse);
      setIsLoggedIn(true);
    } else {
      setIsLoggedIn(false);
    }
  }, []);

  function logOut() {
    localStorage.removeItem('userData');
    setIsLoggedIn(false);
    router.push('/sign-in');
  }

  const renderSidebarMenu = (items: any[]) => {
    return (
      <SidebarMenu>
        {items.map((item) => {
          const isActive = currentPath === item.url;
          return (
            <SidebarMenuItem key={item.title}>
              <SidebarMenuButton asChild>
                <a
                  href={item.url}
                  className={`flex items-center space-x-2 transition-all ease-linear ${
                    isActive
                      ? 'bg-blue-500 text-white rounded p-2'
                      : 'hover:bg-gray-200 text-gray-900 p-2'
                  }`}
                >
                  <item.icon />
                  <span>{item.title}</span>
                </a>
              </SidebarMenuButton>
            </SidebarMenuItem>
          );
        })}
      </SidebarMenu>
    );
  };

  const getMenuItems = () => {
    if (currentUser?.Role === 'Admin') {
      return [...commonItems, ...adminItems];
    }
    if (currentUser?.Role === 'Student') {
      return [...commonItems, ...studentItems];
    }
    return commonItems; // Default menu for guests (not logged in)
  };

  return (
    <Sidebar className="border-none">
      <SidebarContent>
        <SidebarGroup>
          <SidebarGroupLabel className="my-5">
            <div className="gap-2 hstack">
              <Image src="/logo.png" alt="Logo" width={50} height={50} />
              <div className="items-center w-full hstack">
                <h1 className="font-bold !text-2xl text-black title">Admin Connect</h1>
              </div>
            </div>
          </SidebarGroupLabel>
          <SidebarGroupContent>
            {isLoggedIn ? renderSidebarMenu(getMenuItems()) : renderSidebarMenu(commonItems)} 
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>
      {isLoggedIn && (
       <SidebarFooter className="relative bg-[url('/school.jpg')] bg-cover bg-center rounded-t-lg w-[101%] overflow-hidden">
       <div className="absolute inset-0 bg-black opacity-50"></div> 
       <div className="relative z-10 gap-2 rounded-xl hstack">
         <Image src="/logo.png" alt="Logo" width={50} height={50} />
         <div className="justify-center items-start w-full text-white vstack">
           <h1 className="font-semibold">
             {currentUser?.Fname} {currentUser?.Lname}
           </h1>

           <div className="flex flex-wrap gap-1 text-sm">
            {currentUser?.Role && <h2>{currentUser.Role}</h2>}
            {currentUser?.Role !== "Admin" && (
              <>
                <p>-</p>
                <p>{currentUser?.YearLevel}</p>
                <p>{currentUser?.Block}</p>
               </>
            )}
          </div>


         </div>
         <LogOutIcon
           onClick={logOut}
           className="flex my-auto w-7 h-7 text-white cursor-pointer"
         />
       </div>
     </SidebarFooter>
     
      )}
    </Sidebar>
  );
}
