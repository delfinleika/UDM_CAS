'use client';
import { MessageCircleCodeIcon, X } from 'lucide-react';
import React, { useState } from 'react';
import CustomInput from './UI/CustomInput';

type ChatMessage = {
  sender: 'user' | 'bot';
  message: string;
};

const Chatbot: React.FC = () => {
  const [isChatOpen, setChatOpen] = useState<boolean>(false);
  const [chatBody, setChatBody] = useState<ChatMessage[]>([
    { sender: 'bot', message: 'How can I assist you today?' },
    { sender: 'bot', message: "- Type 'menu' for options" },
  ]);
  const [state, setState] = useState<string>('initial');
  const [userInput, setUserInput] = useState<string>('');

  const openChat = () => setChatOpen(true);

  const closeChat = () => setChatOpen(false);

  const handleBotResponse = (input: string) => {
    let response = '';

    switch (state) {
      case 'initial':
        if (input === 'menu') {
          response = 'Please choose an option:<br>1. Subject Information<br>2. Contact Information<br>3. Transfer Requirements<br>4. Exit';
          setState('menu');
        } else {
          response = 'I didn’t understand that. Please type "menu" to see options.';
        }
        break;

      case 'menu':
        switch (input) {
          case '1':
            response = 'Please specify the year level you’re interested in:<br>1. 1st Year<br>2. 2nd Year<br>3. 3rd Year<br>4. 4th Year';
            setState('waitingForYearLevel');
            break;
          case '2':
            response = 'Our office hours are Monday to Friday, 9 AM to 5 PM. You can reach us at contact@udm.yapak@gmail.com.';
            setState('waitingForContactResponse');
            break;
          case '3':
            response = 'Here are the requirements for transfer:<br>- Completed application form<br>- Official transcript of records<br>- Certificate of good moral character.';
            setState('waitingForTransferResponse');
            break;
          case '4':
            closeChat();
            return;
          default:
            response = 'Please choose a valid option from the menu.';
        }
        break;

      case 'waitingForYearLevel':
        if (['1', '2', '3', '4'].includes(input)) {
          response = `You selected year level ${input}. Would you like to proceed further with specific subjects?`;
          setState('waitingForSubjectDetail');
        } else {
          response = 'Invalid selection. Please type a valid number.';
        }
        break;

      default:
        response = 'I did not understand that. Please type "menu" to try again.';
    }

    return response;
  };

  const handleKeyDown = (event: React.KeyboardEvent<HTMLInputElement>) => {
    if (event.key === 'Enter') {
      const input = userInput.toLowerCase().trim();
      setChatBody((prev) => [
        ...prev,
        { sender: 'user', message: userInput },
      ]);
      setUserInput('');

      const botResponse = handleBotResponse(input);

      if (botResponse) {
        setChatBody((prev) => [
          ...prev,
          { sender: 'bot', message: botResponse },
        ]);
      }
    }
  };

  return (
    <div className='right-5 bottom-5 z-50 fixed bg-blue-200 px-5 py-2 rounded-xl text-xs'>
      {/* Open Chat Button */}
      {!isChatOpen && (
        <button
          className="items-center gap-1 text-lg hstack title"
          onClick={openChat}
        >
          <MessageCircleCodeIcon className='w-5 h-5'/>
          Open Chat
        </button>
      )}

      {/* Chatbot UI */}
      {isChatOpen && (
        <div className='relative'>
          <div className='relative'>
            <p className='my-2 font-bold text-center text-xl title'>CPA Chatbot</p>
            <button
              className="top-0 right-0 absolute bg-blue-300 p-1 rounded-lg text-white"
              onClick={closeChat}
            >
              <X className='w-4 h-4'/>
            </button>
          </div>
          <div className='px-2 md:w-[250px] max-h-[150px] !text-xs overflow-x-hidden overflow-y-auto'>
            {chatBody.map((chat, index) => (
              <p
                key={index}
                className='mb-3'
                dangerouslySetInnerHTML={{
                  __html: `${chat.sender === 'user' ? '<b>You: </b>' : '<b> </b>'}${chat.message}`,
                }}
              />
            ))}
          </div>
          <CustomInput
            className='flex my-2 w-full'
            type="text"
            placeholder="Ask me something..."
            onChange={(e) => setUserInput(e.target.value)}
            onKeyPress={handleKeyDown} // Updated to `onKeyDown`
            value={userInput}
          />
        </div>
      )}
    </div>
  );
};

export default Chatbot;
