import React from 'react'

export interface CustomButtonProps{
  placeholder: string,
  className?: string,
  disabled?: boolean,
  onClick?: () => void;
}

const CustomButton:React.FC<CustomButtonProps> = ({placeholder, disabled, className, onClick}) => {
  return (
    <>
        <button onClick={onClick} disabled={disabled} className={`${className} bg-red-500 px-5 py-3 rounded-xl max-w-fit font-semibold text-white`}>
            {placeholder}
        </button>
    </>
  )
}

export default CustomButton