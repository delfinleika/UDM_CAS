import { LoaderProps } from '@/types/props/LoaderProps'
import React from 'react'

const Loader:React.FC<LoaderProps> = ({className}) => {
  return (
     <div className={`${className} loader`}></div> 
  )
}

export default Loader