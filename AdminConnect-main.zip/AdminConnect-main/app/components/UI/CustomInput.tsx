import React, { forwardRef } from 'react'

export interface CustomInputProps{
  placeholder: string,
  className?: string,
  isHidden?: string,
  value?: string,
  name?: string,
  type?: 'text' | 'password' | 'email';
  onChange?: (e: React.ChangeEvent<HTMLInputElement>) => void;
  onKeyPress?: (event: React.KeyboardEvent<HTMLInputElement>) => void;

  // needed for zod ( name, onChange, ref )
}

const CustomInput = forwardRef<HTMLInputElement, CustomInputProps>(
  ({placeholder, className, name, value, onChange, onKeyPress, type = 'text'}, ref) => {
    return (
      <>
          <input type={type} ref={ref} value={value} name={name} onKeyPress={onKeyPress} placeholder={placeholder} onChange={onChange} className={`${className} py-3 px-5 rounded-lg outline-none bg-[#EAF0FD]`}/>
      </>
    )
  }
)

export default CustomInput