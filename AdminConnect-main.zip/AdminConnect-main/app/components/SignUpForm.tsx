'use client';
import React, { useState } from 'react';
import CustomInput from './UI/CustomInput';
import CustomButton from './UI/CustomButton';
import { useRouter } from 'next/navigation';

interface SignUpResponse {
  message: string;
  token: string;
}

const SignUpForm = () => {
  const router = useRouter();

  // State to track form input
  const [formData, setFormData] = useState({
    fname: '',
    lname: '',
    address: '',
    phone: '',
    emailAddress: '',
    password: '',
    confirmPassword: '',
    course: '',
    yearLevel: '',
    block: '',
  });

  const generateUserId = (lname: string) => {
    const randomNumber = Math.floor(1000 + Math.random() * 9000); // Random 4-digit number
    return `${lname}${randomNumber}`;
  };

  const [errorMessage, setErrorMessage] = useState<string>(''); 
  const [isLoading, setIsLoading] = useState<boolean>(false);

  // Handle form input field change
  const handleOnChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;

    setFormData((prevState) => ({
      ...prevState,
      [name]: value,
    }));
  };

  const submitForm = async (e: React.FormEvent) => {
    e.preventDefault();
  
    // Input validation before sending a request
    if (formData.password !== formData.confirmPassword) {
      setErrorMessage('Passwords do not match');
      return;
    }
  
    if (!formData.emailAddress || !formData.fname || !formData.lname) {
      setErrorMessage('Please fill all required fields');
      return;
    }
  
    const userId = `${formData.lname}-${generateUserId(formData.lname)}`;
  
    try {
      setIsLoading(true);
      setErrorMessage(''); // Clear error message
  
      const response = await fetch('http://localhost:3001/users/', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          UserId: userId,
          Fname: formData.fname,
          Lname: formData.lname,
          Address: formData.address,
          Phone: formData.phone,
          EmailAddress: formData.emailAddress,
          Password: formData.password,
          Role: "Student",
          Course: formData.course,
          YearLevel: formData.yearLevel,
          Block: formData.block,
        }),
      });
  
      if (!response.ok) {
        const errorResponse = await response.json(); // Attempt to read error message from server
        alert(errorResponse?.message || 'Signup failed. Please check your inputs.');
        return;
      }
  
      const data: SignUpResponse = await response.json();
      console.log('Signup successful:', data);
  
      // Handle successful signup
      localStorage.setItem('auth_token', data.token);
  
      alert('Account successfully created! Redirecting to Sign In...');
      router.push('/sign-in');
    } catch (error: unknown) {
      if (error instanceof Error) {
        console.error('Error during signup:', error.message);
        setErrorMessage(error.message);
      } else {
        console.error('Unexpected error occurred during signup');
        setErrorMessage('Unexpected error occurred. Please try again later.');
      }
    } finally {
      setIsLoading(false); // Reset loading state
    }
  };
  return (
    <div className="relative z-50 gap-5 bg-gray-50 m-auto p-10 rounded-xl w-[500px] vstack">
      <h1 className="mb-4 font-bold text-center text-lg">Sign up</h1>

      <form className="gap-4 vstack" onSubmit={submitForm}>

        <CustomInput
          placeholder="First Name"
          name="fname"
          value={formData.fname}
          onChange={handleOnChange}
        />
        <CustomInput
          placeholder="Last Name"
          name="lname"
          value={formData.lname}
          onChange={handleOnChange}
        />
        <CustomInput
          placeholder="Address"
          name="address"
          value={formData.address}
          onChange={handleOnChange}
        />
        <CustomInput
          placeholder="Phone"
          name="phone"
          value={formData.phone}
          onChange={handleOnChange}
        />
        <CustomInput
          placeholder="Email Address"
          name="emailAddress"
          value={formData.emailAddress}
          onChange={handleOnChange}
        />
        <CustomInput
          placeholder="Password"
          type="password"
          name="password"
          value={formData.password}
          onChange={handleOnChange}
        />
        <CustomInput
          placeholder="Confirm Password"
          type="password"
          name="confirmPassword"
          value={formData.confirmPassword}
          onChange={handleOnChange}
        />
        
        <div className='gap-5 grid md:grid-cols-8'>
    
        <CustomInput
          placeholder="Course"
          name="course"
          value={formData.course}
          onChange={handleOnChange}
          className='md:col-span-3'
        />
    
        <CustomInput
          placeholder="Block"
          name="block"
          value={formData.block}
          onChange={handleOnChange}
          className='md:col-span-3'

        />
        <CustomInput
          placeholder="Year"
          name="yearLevel"
          value={formData.yearLevel}
          onChange={handleOnChange}
          className='md:col-span-2'
        />
        </div>

        {/* Submit button */}
        <CustomButton
          placeholder={isLoading ? 'Signing Up...' : 'Sign Up'}
          className="mt-4 !min-w-full text-sm"
          disabled={isLoading}
        />
      </form>

      {/* Display error messages */}
      {errorMessage && <p className="mt-2 text-red-500 text-sm">{errorMessage}</p>}

      {/* Redirect to sign-in */}
      <p className="flex gap-2 mt-3 text-sm">
        <span className="text-slate-500">Already have an account?</span>
        <a className="text-blue-500 hover:text-blue-700" href="/sign-in">Login here</a>
      </p>
    </div>
  );
};

export default SignUpForm;
