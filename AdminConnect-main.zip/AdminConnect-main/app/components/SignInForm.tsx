'use client';
import React, { useEffect, useState } from 'react';
import CustomInput from './UI/CustomInput';
import CustomButton from './UI/CustomButton';
import { User } from '../model/user';
import { redirect, useRouter } from 'next/navigation';
import { UserResponse } from '../helpers/helpers';


 const  SignInForm =  () => {
  const router = useRouter();

  const [formData, setFormData] = useState<User>({
    emailAddress: '',
    password: '',
  });

  const [errorMessage, setErrorMessage] = useState<string>(''); 
  const [isLoading, setIsLoading] = useState<boolean>(false);

  const handleOnChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;

    setFormData((prevState) => ({
      ...prevState,
      [name]: value,
    }));
  };

  const submitButton = async (e: React.FormEvent) => {
    e.preventDefault();
    
    try {
      setIsLoading(true); // Start loading
      setErrorMessage(''); // Clear any previous errors
  
      // Send the login request
      const response = await fetch('http://localhost:3001/users/loginJWT', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          EmailAddress: formData.emailAddress,
          Password: formData.password,
        }),
      });
  
      // Handle case where response isn't OK
      if (!response.ok) {
        const errorResponse = await response.json();
        alert(errorResponse?.message || 'Login failed. Please check your credentials.');
        return;
      }
  
      // Parse successful login response
      const data: UserResponse = await response.json();
      
      console.log('Login successful:', data);
  
      const userResponse: UserResponse = data;
      localStorage.setItem('userData', `${userResponse.UserId}-${userResponse.Fname}-${userResponse.Lname}-${userResponse.Role}-${userResponse.Block}-${userResponse.YearLevel}`);
  
      alert(`Welcome ${userResponse.Fname} ${userResponse.Lname}${userResponse.Role !== "Admin" ? ` from ${userResponse.Block}-${userResponse.YearLevel}!` : "!"}\nYou're logged in as a ${userResponse.Role}.`);

      // Redirect based on role
      if (userResponse.Role === 'Admin') {
        router.push('/home');
      } else {
        router.push('/evaluate');
      }
  
    } catch (error: unknown) {
      if (error instanceof Error) {
        // console.error('Error during login:', error.message);
        setErrorMessage("Failed to Login. Please check your credentials.");
      } else {
        // console.error('Failed to Login. Please check your credentials.');
        setErrorMessage('Failed to Login. Please check your credentials.');
      }
    } finally {
      setIsLoading(false); // Stop loading
    }
  };
  
  return (
    <div className="relative z-50 gap-5 bg-gray-50 m-auto p-10 rounded-xl w-[400px] vstack">
      <h1 className="font-bold">Sign in</h1>

      <form
        className="gap-5 vstack"
        onSubmit={submitButton}
      >
        <CustomInput
          placeholder="Email Address"
          name="emailAddress"
          value={formData.emailAddress}
          onChange={handleOnChange}
        />

        <CustomInput
          placeholder="Password"
          type="password"
          name="password"
          value={formData.password}
          onChange={handleOnChange}
        />

        <CustomButton
          placeholder={isLoading ? 'Loading...' : 'Login'}
          className={`mt-5 !min-w-full text-sm`}
          disabled={isLoading}
        />
      </form>

      {/* Error Message */}
      {errorMessage && <p className="text-red-500 text-sm">{errorMessage}</p>}

      <p className="flex gap-1 text-sm">
        <span className="text-slate-500">First time?</span>
        <a href="/sign-up">Create an account</a>
      </p>
    </div>
  );
};

export default SignInForm;
