"use client"
import { TrendingUp } from "lucide-react"
import { Bar, BarChart, CartesianGrid, XAxis } from "recharts"
import {
  Card,
  CardContent,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card"
import {
  ChartConfig,
  ChartContainer,
  ChartTooltip,
  ChartTooltipContent,
} from "@/components/ui/chart"
import { useEffect, useState } from "react"
import { EvaluationResponse } from "./TableListEvaluated"

const chartConfig = {
  teacher: {
    label: "Teacher",
    color: "hsl(210, 50%, 30%)", // Dark blue
  },
  performance: {
    label: "Perf.",
    color: "hsl(210, 50%, 50%)", // Medium blue
  },
  communication: {
    label: "Comm.",
    color: "hsl(210, 50%, 65%)", // Light blue
  },
  ethics: {
    label: "Ethics",
    color: "hsl(210, 50%, 85%)", // Very light blue
  },
} satisfies ChartConfig;


export function BarChartTeachers() {
  const [evaluations, setEvaluations] = useState<EvaluationResponse[]>([])
  const [chartData, setChartData] = useState<any[]>([])

  useEffect(() => {
    const fetchUsers = async () => {
      try {
        const response = await fetch('http://localhost:3001/evaluation')
        if (!response.ok) {
          throw new Error(`Failed to fetch users: ${response.statusText}`)
        }

        const data: EvaluationResponse[] = await response.json()
        console.log('Fetched data: ', data)
        setEvaluations(data)
      } catch (err) {
        console.error('Error fetching users:', err)
      }
    }

    fetchUsers()
  }, [])

  useEffect(() => {
    const mappedChartData = evaluations.map((evaluation) => ({
      teacher: evaluation.teacher_name,
      performance: evaluation.performance_rating,
      communication: evaluation.communication_rating,
      ethics: evaluation.ethics_rating,
    }))
    setChartData(mappedChartData)
  }, [evaluations])

  return (
    <Card>
      <CardHeader>
        <CardTitle>Evaluation Results</CardTitle>
      </CardHeader>
      <CardContent>
        <ChartContainer config={chartConfig}  className="max-h-[500px]">
          <BarChart accessibilityLayer data={chartData}>
            <CartesianGrid vertical={false} />
            <XAxis
              dataKey="teacher"
              tickLine={false}
              tickMargin={10}
              axisLine={false}
              tickFormatter={(value) => value.slice(0, 9)}
            />
            <ChartTooltip
              cursor={false}
              content={<ChartTooltipContent indicator="dashed" />}
            />
            <Bar
              dataKey="performance"
              fill={chartConfig.performance.color} 
              radius={4}
            />
            <Bar
              dataKey="communication"
              fill={chartConfig.communication.color} 
              radius={4}
            />
            <Bar
              dataKey="ethics"
              fill={chartConfig.ethics.color} 
              radius={4}
            />
          </BarChart>
        </ChartContainer>
      </CardContent>
      <CardFooter className="flex-col items-start gap-2 text-sm">
        <div className="flex gap-2 font-medium leading-none">
          Evaluation Results <TrendingUp className="w-4 h-4" />
        </div>
        <div className="text-muted-foreground leading-none">
          For Performance, Communication and Ethics
        </div>
      </CardFooter>
    </Card>
  )
}
