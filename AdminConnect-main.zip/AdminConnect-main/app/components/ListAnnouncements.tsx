'use client';
import Image from 'next/image';
import React, { useEffect, useState } from 'react';
import { getUserResponse } from '../helpers/helpers';
import { Delete, DeleteIcon, Trash } from 'lucide-react';

export interface AnnouncementResponse {
  id: number;
  title: string;
  content: string;
  date: string;
  author: string;
}

export const ListAnnouncements: React.FC = () => {
  const [evaluations, setEvaluations] = useState<AnnouncementResponse[]>([]);
  const [userRole, setUserRole] = useState<string>(''); // Track user role

  useEffect(() => {
    const userResponse = getUserResponse();
    setUserRole(userResponse.Role);

    const fetchUsers = async () => {
      try {
        const response = await fetch('http://localhost:3001/announcement');
        if (!response.ok) {
          throw new Error(`Failed to fetch users: ${response.statusText}`);
        }
        const data: AnnouncementResponse[] = await response.json();
        setEvaluations(data);
      } catch (err) {
        console.error('Error fetching users:', err);
      }
    };

    fetchUsers();
  }, []);

  const handleDelete = async (id: number) => {
    try {
      const response = await fetch(`http://localhost:3001/announcement/${id}`, {
        method: 'DELETE',
      });

      if (!response.ok) {
        throw new Error('Failed to delete the announcement');
      }

      alert('Announcement deleted successfully!');
      // Remove the deleted announcement from state after successful DELETE
      setEvaluations((prev) => prev.filter((item) => item.id !== id));
    } catch (error) {
      console.error('Error deleting announcement:', error);
      alert('Failed to delete the announcement. Please try again.');
    }
  };

  return (
    <>
      <ul className='gap-x-5 gap-y-10 grid grid-cols-1 md:grid-cols-4 w-full'>
        {evaluations.map((announcement) => (
          <div
            key={announcement.id}
            className="relative bg-gray-50 shadow-lg hover:shadow-xl p-4 rounded-lg transform transition-all duration-200 ease-in-out hover:scale-105"
          >
            <div className="flex justify-center items-center bg-[url('/school.jpg')] bg-gray-50 bg-cover bg-center mb-2 rounded-md w-full h-24">
              <Image
                src="/logo.png"
                alt="announcement-image"
                width={60}
                height={60}
                className="object-cover"
              />
            </div>

            <div className="flex flex-col gap-2">
              <div className='flex justify-end items-center'>
                <p className="bg-blue-600 px-2 py-1 rounded-md w-fit text-[9px] text-end text-white">
                  {new Date(announcement.date).toLocaleDateString()}
                </p>
              </div>
              <h3 className="font-semibold text-gray-800 text-lg leading-tight">
                {announcement.title}
              </h3>

              <div className='p-2 max-h-[150px] overflow-hidden overflow-y-auto'>
              <p className="text-gray-700 text-sm leading-snug">
                {announcement.content}
              </p>
              </div>
             
                <div className='top-3 right-5 absolute'>
                    {userRole === 'Admin' && (
                      <button
                        className="bg-red-500 hover:bg-red-600 mt-2 p-1 rounded-md text-sm text-white self-end"
                        onClick={() => handleDelete(announcement.id)}
                      >
                        <Trash className='w-4 h-4' />
                      </button>
                    )}
                </div>
            </div>
          </div>
        ))}
      </ul>
    </>
  );
};

export default ListAnnouncements;
