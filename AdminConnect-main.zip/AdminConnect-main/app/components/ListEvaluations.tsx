'use client';
import React, { useEffect, useState } from 'react';

export interface EvaluationResponse {
  Id: number;
  evaluation_date: string; 
  feedback: string; 
  performance_rating: number; 
  communication_rating: number; 
  ethics_rating: number; 
  teacher_name: string; 
  student_id: number;
  subject: string;
  student_name: string; 
  block: string; 
}

export const ListEvaluations: React.FC = () => {
  const [evaluations, setEvaluations] = useState<EvaluationResponse[]>([]);

  useEffect(() => {
    const fetchUsers = async () => {
      try {
        const response = await fetch('http://localhost:3001/evaluation');

        console.log(response)
        if (!response.ok) {
          throw new Error(`Failed to fetch users: ${response.statusText}`);
        }

        const data: EvaluationResponse[] = await response.json();
        console.log(data);
        
        setEvaluations(data);
      } catch (err) {
        console.error('Error fetching users:', err);
      } finally {
      }
    };

    fetchUsers();
  }, []);

  return (
    <div className="bg-gray-50 shadow-md p-5 rounded-lg w-full">
      <h1 className="mb-4 font-bold text-lg">Evaluated Teachers</h1>
      <ul className='max-h-[500px] overflow-hidden overflow-y-auto'>
        {evaluations.map((ev) => (
          <li key={ev.Id} className="mb-2">
           {ev.teacher_name} - {ev.subject} 
          </li>
        ))}
      </ul>
    </div>
  );
};

export default ListEvaluations;
