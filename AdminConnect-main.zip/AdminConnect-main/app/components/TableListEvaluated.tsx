"use client";

import * as React from "react";
import {
  ColumnDef,
  ColumnFiltersState,
  SortingState,
  VisibilityState,
  flexRender,
  getCoreRowModel,
  getFilteredRowModel,
  getPaginationRowModel,
  getSortedRowModel,
  useReactTable,
} from "@tanstack/react-table";
import { ArrowUpDown } from "lucide-react";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Checkbox } from "@/components/ui/checkbox";

// Interface to define the shape of the evaluation data
export interface EvaluationResponse {
  Id: number;
  evaluation_date: string;
  feedback: string;
  performance_rating: number;
  communication_rating: number;
  ethics_rating: number;
  teacher_name: string;
  student_id: number;
  subject: string;
  student_name: string;
  block: string;
};

// Define table columns that map to `EvaluationResponse`
export const columns: ColumnDef<EvaluationResponse>[] = [
//   {
//     id: "select",
//     header: ({ table }) => (
//       <Checkbox
//         checked={
//           table.getIsAllPageRowsSelected() ||
//           (table.getIsSomePageRowsSelected() && "indeterminate")
//         }
//         onCheckedChange={(value: any) => table.toggleAllPageRowsSelected(!!value)}
//         aria-label="Select all"
//       />
//     ),
//     cell: ({ row }) => (
//       <Checkbox
//         checked={row.getIsSelected()}
//         onCheckedChange={(value: any) => row.toggleSelected(!!value)}
//         aria-label="Select row"
//       />
//     ),
//     enableSorting: false,
//     enableHiding: false,
//   },
  {
    accessorKey: "evaluation_date",
    header: "Evaluation Date",
    cell: ({ row }) => (
      <div className="capitalize">{new Date(row.getValue("evaluation_date")).toLocaleDateString()}</div>
    ),
  },
  {
    accessorKey: "teacher_name",
    header: "Teacher Name",
    cell: ({ row }) => (
      <div className="capitalize">{row.getValue("teacher_name")}</div>
    ),
  },
  {
    accessorKey: "subject",
    header: "Subject",
    cell: ({ row }) => (
      <div className="capitalize">{row.getValue("subject")}</div>
    ),
  },
  {
    accessorKey: "feedback",
    header: "Feedback",
    cell: ({ row }) => (
      <div className="text-sm">{row.getValue("feedback")}</div>
    ),
  },
  {
    accessorKey: "performance_rating",
    header: "Performance Rating",
    cell: ({ row }) => (
      <div className="text-center">{row.getValue("performance_rating")}</div>
    ),
  },
  {
    accessorKey: "communication_rating",
    header: "Communication Rating",
    cell: ({ row }) => (
      <div className="text-center">{row.getValue("communication_rating")}</div>
    ),
  },
  {
    accessorKey: "ethics_rating",
    header: "Ethics Rating",
    cell: ({ row }) => (
      <div className="text-center">{row.getValue("ethics_rating")}</div>
    ),
  },

//   {
//     accessorKey: "student_name",
//     header: "Student Name",
//     cell: ({ row }) => (
//       <div className="capitalize">{row.getValue("student_name")}</div>
//     ),
//   },
 
//   {
//     accessorKey: "block",
//     header: "Block",
//     cell: ({ row }) => (
//       <div className="capitalize">{row.getValue("block")}</div>
//     ),
//   },
];

export function DataTableDemo() {
  const [data, setEvaluations] = React.useState<EvaluationResponse[]>([]);

  // Fetch data from the server
  React.useEffect(() => {
    const fetchEvaluations = async () => {
      try {
        const response = await fetch("http://localhost:3001/evaluation");

        if (!response.ok) {
          throw new Error(`Failed to fetch evaluations: ${response.statusText}`);
        }

        const data: EvaluationResponse[] = await response.json();
        console.log("Fetched evaluations data:", data);

        setEvaluations(data);
      } catch (error) {
        console.error("Error fetching evaluations:", error);
      }
    };

    fetchEvaluations();
  }, []);

  const [sorting, setSorting] = React.useState<SortingState>([]);
  const [columnFilters, setColumnFilters] = React.useState<ColumnFiltersState>([]);
  const [columnVisibility, setColumnVisibility] = React.useState<VisibilityState>({});
  const [rowSelection, setRowSelection] = React.useState({});

  const table = useReactTable({
    data,
    columns,
    onSortingChange: setSorting,
    onColumnFiltersChange: setColumnFilters,
    getCoreRowModel: getCoreRowModel(),
    getPaginationRowModel: getPaginationRowModel(),
    getSortedRowModel: getSortedRowModel(),
    getFilteredRowModel: getFilteredRowModel(),
    onColumnVisibilityChange: setColumnVisibility,
    onRowSelectionChange: setRowSelection,
    state: {
      sorting,
      columnFilters,
      columnVisibility,
      rowSelection,
    },
  });

  return (
    <div className="my-5 w-full">
      {/* <div className="flex items-center py-4">
        <Input
          placeholder="Filter feedback..."
          value={(table.getColumn("feedback")?.getFilterValue() as string) ?? ""}
          onChange={(event) =>
            table.getColumn("feedback")?.setFilterValue(event.target.value)
          }
          className="max-w-sm"
        />
      </div> */}
      <div className="shadow-md border rounded-md">
        <Table>
          <TableHeader>
            {table.getHeaderGroups().map((headerGroup) => (
              <TableRow key={headerGroup.id}>
                {headerGroup.headers.map((header) => {
                  return (
                    <TableHead key={header.id} className="p-5 text-center">
                      {header.isPlaceholder
                        ? null
                        : flexRender(
                            header.column.columnDef.header,
                            header.getContext()
                          )}
                    </TableHead>
                  );
                })}
              </TableRow>
            ))}
          </TableHeader>
          <TableBody>
            {table.getRowModel().rows?.length ? (
              table.getRowModel().rows.map((row) => (
                <TableRow
                  key={row.id}
                  data-state={row.getIsSelected() && "selected"}
                >
                  {row.getVisibleCells().map((cell) => (
                    <TableCell key={cell.id} className="py-2 text-center">
                      {flexRender(
                        cell.column.columnDef.cell,
                        cell.getContext()
                      )}
                    </TableCell>
                  ))}
                </TableRow>
              ))
            ) : (
              <TableRow>
                <TableCell colSpan={columns.length} className="h-24 text-center">
                  No evaluations found.
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}
