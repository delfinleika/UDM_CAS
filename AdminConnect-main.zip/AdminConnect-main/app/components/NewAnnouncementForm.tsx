'use client';
import React, { useState } from 'react';
import { useRouter } from 'next/navigation';
import CustomInput from './UI/CustomInput';
import CustomButton from './UI/CustomButton';

interface AnnouncementFormData {
  title: string;
  content: string;
  date: string;
  author: string;
}

const NewAnnouncementForm = () => {
  const router = useRouter();

  const [formData, setFormData] = useState<AnnouncementFormData>({
    title: '',
    content: '',
    date: '',
    author: '',
  });

  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [errorMessage, setErrorMessage] = useState<string>('');

  const handleOnChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;

    setFormData((prevState) => ({
      ...prevState,
      [name]: value,
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      setIsLoading(true);
      setErrorMessage('');

      const response = await fetch('http://localhost:3001/announcement/sendAnnouncement', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(formData),
      });

      if (!response.ok) {
        throw new Error('Failed to send announcement');
      }

      const result = await response.json();
      console.log('Announcement successfully created:', result);

      alert('Announcement created successfully!');
      router.push('/announcements');
    } catch (error: unknown) {
      if (error instanceof Error) {
        setErrorMessage(error.message);
      } else {
        setErrorMessage('Unexpected error occurred.');
      }
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="relative z-50 gap-5 bg-gray-50 m-auto p-10 rounded-xl w-[500px] vstack">
      <h1 className="font-bold">Create a New Announcement</h1>

      <form
        className="gap-5 vstack"
        onSubmit={handleSubmit}
      >
        <CustomInput
          placeholder="Announcement Title"
          name="title"
          value={formData.title}
          onChange={handleOnChange}
        />

        <textarea
          className="bg-[#EAF0FD] p-2 border rounded-md max-h-[250px]"
          placeholder="Announcement Content"
          name="content"
          value={formData.content}
          onChange={handleOnChange}
        />

        <input
          type="date"
          className="bg-[#EAF0FD] p-2 border rounded-md"
          name="date"
          value={formData.date}
          onChange={handleOnChange}
        />

        <CustomInput
          placeholder="Author Name"
          name="author"
          value={formData.author}
          onChange={handleOnChange}
        />

        <CustomButton
          placeholder={isLoading ? 'Loading...' : 'Submit'}
          className={`mt-5 !min-w-full text-sm`}
          disabled={isLoading}
        />
      </form>

      {errorMessage && <p className="text-red-500 text-sm">{errorMessage}</p>}
    </div>
  );
};

export default NewAnnouncementForm;
