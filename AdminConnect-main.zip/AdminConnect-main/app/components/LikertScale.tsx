'use client';
import React, { useState, useEffect } from 'react';
import CustomButton from './UI/CustomButton';
import { useRouter } from 'next/navigation';
import { getUserResponse, UserResponse } from '../helpers/helpers';

interface QuestionData {
  id: string;
  text: string;
  category: string;
}

interface Question {
  title: string;
  questions: QuestionData[];
}

const questions: Question[] = [
  {
    title: 'Performance',
    questions: [
      { id: 'performance_1', text: 'The instructor was knowledgeable in the course subject matter and well prepared for each class.', category: 'Performance' },
      { id: 'performance_2', text: 'The instructor clearly explained the course material.', category: 'Performance' },
      { id: 'performance_3', text: 'The instructor presented the course material in a way that was accessible.', category: 'Performance' },
      { id: 'performance_4', text: 'The instructor provided guidance for understanding course exercises.', category: 'Performance' },
    ],
  },
  {
    title: 'Communication',
    questions: [
      { id: 'communication_1', text: 'The professor encourages students to ask questions and seek clarification.', category: 'Communication' },
      { id: 'communication_2', text: 'Instructions and course expectations are clearly communicated to students.', category: 'Communication' },
      { id: 'communication_3', text: 'The professor encourages students to ask questions and seek clarification.', category: 'Communication' },
    ],
  },
  {
    title: 'Ethics',
    questions: [
      { id: 'ethics_1', text: 'The professor demonstrates professionalism in their conduct and communication.', category: 'Ethics' },
      { id: 'ethics_2', text: 'Ethical standards are upheld in all aspects of teaching and assessment.', category: 'Ethics' },
      { id: 'ethics_3', text: 'The professor maintains appropriate boundaries and respects student privacy.', category: 'Ethics' },
      { id: 'ethics_4', text: 'The professor demonstrates professionalism in their conduct and communication.', category: 'Ethics' },
    ],
  },
];

const sectionData = [
  {
    section: "BPA-41",
    subjects: [
      { name: "Research II (Research Methods in PA)", professor: "Rosalie Catu" },
      { name: "Service Delivery System (elective)", professor: "Sheila Estrada" },
      { name: "Special Topics/Problems in PA", professor: "George Quiambao" },
      { name: "Environmental Management (elective)", professor: "Marcial Diom" },
      { name: "Globalization in Public Administration (elective)", professor: "Marcial Diom" },
      { name: "Salary Administration", professor: "George Quiambao" },
      { name: "Public Administration & the Economic System", professor: "Perfecto Barrameda" },
    ],
  },
  {
    section: "BPA-31",
    subjects: [
      { name: "Public Fiscal Administration", professor: "Cresencio Laurente" },
      { name: "Law on Obligation and Contract", professor: "Ronn Vincent Joaquin" },
      { name: "Entrepreneurship in Public Sector", professor: "Marcial Diom" },
      { name: "Office System and Management", professor: "Sheila Estrada" },
      { name: "Public Accounting and Budgeting", professor: "Cresencio Laurente" },
      { name: "Statistics in Public Administration", professor: "Regin Carlos Tambo-Ong" },
      { name: "University Identity 5: Achievement and Passion", professor: "Engelbert Yalong" },
    ],
  },
  {
    section: "BPA-22",
    subjects: [
      { name: "Understanding The Self", professor: "Vanessa Martinez" },
      { name: "The Entrepreneurial Mind", professor: "Jhayr Balboa" },
      { name: "University Identity Quality and Excellence", professor: "Manfredo Marcellano" },
      { name: "The Contemporary World", professor: "Ernesto Faraon" },
      { name: "Physical Activities Towards Health and Fitness 3", professor: "Ariel Christopher Marcellino" },
      { name: "Public Organization and Management", professor: "Sheila Estrada" },
      { name: "Politics and Administration", professor: "George Quiambao" },
      { name: "ICT and Knowledge Management for Public Administration", professor: "Perfecto Barrameda" },
    ],
  },
];

const LikertScale = () => {
  const [responses, setResponses] = useState<Record<string, number>>({});
  const [averages, setAverages] = useState<Record<string, number>>({});
  const [teachers, setTeachers] = useState<string[]>([]);
  const [subjects, setSubjects] = useState<string[]>([]);
  const [selectedTeacher, setSelectedTeacher] = useState<string>('');
  const [selectedSubject, setSelectedSubject] = useState<string>('');
  const [evaluationStarted, setEvaluationStarted] = useState(false);
  const [currentUser, setCurrentUser] = useState<UserResponse>({ UserId: '', Fname: '', Lname: '', Role: '', Block: '', YearLevel: '' });
  const [feedbackText, setFeedbackText] = useState<string>(''); 
  const [evaluationDate, setEvaluationDate] = useState<string | null>(null);

  // useEffect(() => {
  //   setEvaluationDate(new Date().toISOString());
  // }, []);

  const router = useRouter();

  useEffect(() => {
    const uniqueTeachers = [...new Set(sectionData.flatMap(section => section.subjects.map(sub => sub.professor)))];
    const uniqueSubjects = [...new Set(sectionData.flatMap(section => section.subjects.map(sub => sub.name)))];
    setTeachers(uniqueTeachers);
    setSubjects(uniqueSubjects);
  }, []);

  useEffect(() => {
    computeAverages();
  }, [responses]);

  useEffect(() => {
    const userResponse = getUserResponse();
    if (userResponse) {
      setCurrentUser(userResponse);

      // alert(`${userResponse.UserId}`);
    } else {

    }
  }, []);

  const handleChange = (id: string, value: number) => {
    const updatedResponses = { ...responses, [id]: value };
    setResponses(updatedResponses);
  };

  const computeAverages = () => {
    const categorySum: Record<string, number[]> = {};
    Object.keys(responses).forEach((id) => {
      const question = findQuestionById(id);
      if (question) {
        if (!categorySum[question.category]) {
          categorySum[question.category] = [];
        }
        categorySum[question.category].push(responses[id]);
      }
    });

    const categoryAverages: Record<string, number> = {};
    for (const category in categorySum) {
      const scores = categorySum[category];
      const avg = scores.reduce((sum, score) => sum + score, 0) / scores.length;
      categoryAverages[category] = parseFloat(avg.toFixed(2));
    }

    setAverages(categoryAverages);
  };

  const findQuestionById = (id: string): QuestionData | undefined => {
    for (const category of questions) {
      for (const question of category.questions) {
        if (question.id === id) return question;
      }
    }
    return undefined;
  };

  const handleStartEvaluation = () => {
    if (selectedTeacher && selectedSubject) {
      setEvaluationStarted(true);
    } else {
      alert('Please select a teacher and subject before proceeding');
    }
  };

  const submitEvaluation = async () => {
    const response = await fetch('http://localhost:3001/evaluation/sendEvaluation', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        student_id: currentUser.UserId,
        evaluation_date: 2024-12-12,
        feedback: feedbackText,
        performance_rating: averages['Performance'] || 0,
        communication_rating: averages['Communication'] || 0,
        ethics_rating: averages['Ethics'] || 0,
        teacher_name: selectedTeacher,
        subject: selectedSubject,
        student_name: `${currentUser.Fname} ${currentUser.Lname}`,
        block: currentUser.Block
      }),
    });

    if (!response.ok) {
      alert("Something went wrong!");
      throw new Error('Error submitting evaluation');
    }

    alert("Successfully submitted evaluation.");
    router.push('/home');
  };

  return (
    <div className='bg-gray-50 mx-auto p-5 rounded-xl w-full max-w-screen-lg overflow-hidden container'>
      <h1 className='font-bold text-2xl text-center title'>Feedback Form</h1>
      <p className="mt-4 text-gray-600 text-sm">
          Please be honest with your evaluation. Your feedback is valuable, and we encourage you to share your thoughts without fear of judgment. Your professors value your opinion for continuous improvement. 
          By providing constructive and sincere feedback, you are helping to enhance the quality of education, improve teaching methods, and create a better learning environment for everyone. 
          Your responses will be reviewed carefully and used to make necessary adjustments and improvements. Remember, your voice matters, and it plays an essential role in shaping the future of the course and its delivery. 
          Thank you for taking the time to contribute to the growth and development of the educational experience.
      </p>
      <p className="mt-4 text-gray-600 text-sm">
          <strong>Rating Scale:</strong><br/>
          <strong>1</strong> - Poor: Needs significant improvement.<br/>
          <strong>2</strong> - Fair: Some improvements are needed.<br/>
          <strong>3</strong> - Good: Meets expectations, but can improve.<br/>
          <strong>4</strong> - Very Good: Exceeds expectations in most areas.<br/>
          <strong>5</strong> - Excellent: Outstanding performance, no improvements needed.
      </p>
      <div className="my-4 vstack">
        <label className="mr-2 font-medium">Select Teacher:</label>
        <select
          value={selectedTeacher}
          onChange={(e) => setSelectedTeacher(e.target.value)}
          className="flex p-2 border rounded w-full"
        >
          <option value="">--Select--</option>
          {teachers.map((teacher, index) => (
            <option key={index} value={teacher}>
              {teacher}
            </option>
          ))}
        </select>
      </div>
      <div className="my-4 vstack">
        <label className="mr-2 font-medium">Select Subject:</label>
        <select
          value={selectedSubject}
          onChange={(e) => setSelectedSubject(e.target.value)}
          className="p-2 border rounded w-full"
        >
          <option value="">--Select--</option>
          {subjects.map((subject, index) => (
            <option key={index} value={subject} className='text-wrap max-md:text-[11px]'>
              {subject}
            </option>
          ))}
        </select>
      </div>
      <button
        onClick={handleStartEvaluation}
        className="bg-blue-500 hover:bg-blue-600 px-4 py-2 rounded text-white"
      >
        Start Evaluation
      </button>
      {evaluationStarted && (
        <div className='mt-10'>
          {questions.map((category) => (
            <div key={category.title} className="mt-4">
              <h2 className="mb-5 font-bold text-lg">{category.title}</h2>
              {category.questions.map((question) => (
  <div key={question.id} className="my-2">
    <p className="font-medium">{question.text}</p>
    <div className="flex gap-2 mt-2">
      {[1, 2, 3, 4, 5].map((value) => (
        <label key={value} className="flex items-center gap-1">
          <input
            type="radio"
            name={question.id}
            value={value}
            checked={responses[question.id] === value}
            onChange={() => handleChange(question.id, value)}
            className="cursor-pointer"
          />
          {value}
        </label>
      ))}
    </div>
  </div>
              ))}

              {/* Display computed average */}
              <div className="bg-gray-200 mt-5 mb-10 p-2 rounded text-center">
                <p className="font-medium">
                  Average Response: {averages[category.title] ? averages[category.title] : 'N/A'}
                </p>
              </div>
            </div>
          ))}
          <div className="my-4">
            <label className="block mb-1 font-medium text-gray-700">
              Feedback:
            </label>
            <textarea
             data-gramm="false"
              value={feedbackText}
              onChange={(e) => setFeedbackText(e.target.value)}
              rows={4}
              className="p-2 border rounded w-full"
              placeholder="Provide additional feedback here..."
            />
          </div>
          <CustomButton
            placeholder="Submit Evaluation"
            className="bg-green-500 hover:bg-green-600 p-2 rounded text-white"
            onClick={submitEvaluation}
          />
        </div>
      )}
    </div>
  );
};

export default LikertScale;
