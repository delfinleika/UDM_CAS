'use client'
import React, { useState, useEffect } from "react";

function Calendar() {
  const [currentDate, setCurrentDate] = useState(new Date());

  const generateCalendarDays = (date: any) => {
    const year = date.getFullYear();
    const month = date.getMonth();

    const firstDayOfMonth = new Date(year, month, 1);
    const lastDayOfMonth = new Date(year, month + 1, 0);
    const firstDayIndex = firstDayOfMonth.getDay();
    const daysInMonth = lastDayOfMonth.getDate();

    const days = [];
    for (let i = 0; i < firstDayIndex; i++) {
      days.push(null); 
    }

    for (let day = 1; day <= daysInMonth; day++) {
      days.push(day);
    }

    return days;
  };

  const daysInCalendar = generateCalendarDays(currentDate);

  const renderCalendarRows = () => {
    const rows = [];
    for (let i = 0; i < daysInCalendar.length; i += 7) {
      rows.push(
        <tr key={i}>
          {daysInCalendar.slice(i, i + 7).map((day, index) => (
            <td key={index} className={day ? "" : "empty-day"}>
              {day || ""}
            </td>
          ))}
        </tr>
      );
    }
    return rows;
  };

  const formatMonthYear = (date: any) => {
    return date.toLocaleString("default", { month: "long", year: "numeric" });
  };

  return (
    <div className="mt-5 container">
      <h2 className="mb-4 text-center">{formatMonthYear(currentDate)}</h2>
      <table className="table-bordered text-center calendar-table table">
        <thead className="thead-light">
          <tr>
            <th>Sun</th>
            <th>Mon</th>
            <th>Tue</th>
            <th>Wed</th>
            <th>Thu</th>
            <th>Fri</th>
            <th>Sat</th>
          </tr>
        </thead>
        <tbody>
          {renderCalendarRows()}
        </tbody>
      </table>
    </div>
  );
};

export default Calendar;
