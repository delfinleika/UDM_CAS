import Image from "next/image";
import CustomButton from "./components/UI/CustomButton";

export default function Home() {

  return (
    <div className="min-h-screen">
    <div className="mx-auto px-4 py-10 container">
      <h1 className="mb-8 font-bold text-4xl text-center title">
        Welcome to the College of Public Administration
      </h1>

      <div className="bg-white shadow-md mb-10 p-6 rounded-lg">
        <h2 className="mb-4 font-semibold text-2xl">Empowering Future Leaders</h2>
        <p className="mb-4 text-gray-700 text-lg">
          We are dedicated to providing high-quality education that fosters
          critical thinking, leadership, and ethical governance among our
          students.
        </p>

        <h2 className="mb-4 font-semibold text-2xl">Our Commitment</h2>
        <p className="mb-4 text-gray-700 text-lg">
          We strive to equip our students with the necessary skills and
          knowledge to become effective leaders in public administration and
          serve their communities with integrity.
        </p>

        <p className="mb-4 text-gray-700 text-lg">
          Explore our programs, participate in our activities, and become a
          part of a community committed to making a difference.
        </p>

        <a href="/sign-in" className="!min-w-full">
        <CustomButton
          placeholder={'Sign in now!'}
          className={`mt-5  !min-w-full text-sm`}
        />
        </a>
      </div>
    </div>
  </div>
  );
}
