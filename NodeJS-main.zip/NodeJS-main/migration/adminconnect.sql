-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 11, 2024 at 03:50 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `adminconnect`
--

-- --------------------------------------------------------

--
-- Table structure for table `announcements`
--

CREATE TABLE `announcements` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `date` datetime NOT NULL DEFAULT current_timestamp(),
  `author` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `announcements`
--

INSERT INTO `announcements` (`id`, `title`, `content`, `date`, `author`) VALUES
(1, 'Important School Update', 'The school will be closed for the holidays from December 20th to January 5th. Please plan accordingly.', '2024-12-01 09:00:00', 'Admin'),
(2, 'Upcoming Parent-Teacher Conference', 'The Parent-Teacher Conference will be held on December 15th, from 9:00 AM to 5:00 PM. All parents are encouraged to attend.', '2024-12-05 10:00:00', 'Principal'),
(3, 'New Library Hours', 'Starting next week, the library will be open on Saturdays from 10:00 AM to 4:00 PM. Don\'t miss out on this extra time to study or borrow books!', '2024-12-06 08:30:00', 'Library Staff'),
(4, 'Winter Sports Registration', 'Winter sports registration is now open for all interested students. The deadline to register is December 10th.', '2024-12-07 14:00:00', 'Sports Coordinator'),
(5, 'Holiday Charity Drive', 'We are collecting donations for the holiday charity drive. Please drop off non-perishable items in the main office by December 18th.', '2024-12-08 11:00:00', 'Student Council'),
(8, 'The quick brown fox jumps over the lazy dog', '\"The quick brown fox jumps over the lazy dog\" is an English-language pangram – a sentence that contains all the letters of the alphabet. The phrase is commonly used for touch-typing practice, testing typewriters and computer keyboards, displaying examples of fonts, and other applications involving text where the use of all letters in the alphabet is desired.', '2025-02-28 00:00:00', 'Wikipedia');

-- --------------------------------------------------------

--
-- Table structure for table `evaluation`
--

CREATE TABLE `evaluation` (
  `Id` int(11) NOT NULL,
  `evaluation_date` date NOT NULL,
  `feedback` text NOT NULL,
  `performance_rating` int(1) NOT NULL,
  `communication_rating` int(1) NOT NULL,
  `ethics_rating` int(1) NOT NULL,
  `teacher_name` varchar(100) NOT NULL,
  `student_id` int(11) NOT NULL,
  `subject` varchar(100) NOT NULL,
  `student_name` varchar(100) NOT NULL,
  `block` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `evaluation`
--

INSERT INTO `evaluation` (`Id`, `evaluation_date`, `feedback`, `performance_rating`, `communication_rating`, `ethics_rating`, `teacher_name`, `student_id`, `subject`, `student_name`, `block`) VALUES
(2, '2023-12-10', 'The teacher explained the concepts clearly and effectively.', 4, 5, 4, 'Rosalie Catu', 12345, 'Research II (Research Methods in PA)', 'John Doe', 'Block A'),
(3, '2023-12-10', 'The teacher explained the concepts clearly and effectively.', 4, 5, 4, 'Cresencio Laurente', 12345, 'Public Fiscal Administration', 'John Doe', 'Block A'),
(4, '2023-12-10', 'The teacher explained the concepts clearly and effectively.', 4, 5, 4, 'Ronn Vincent Joaquin', 12345, 'Law on Obligation and Contract', 'John Doe', 'Block A'),
(5, '2023-12-10', 'The teacher explained the concepts clearly and effectively.', 4, 5, 4, 'Engelbert Yalong', 12345, 'University Identity 5: Achievement and Passion', 'John Doe', 'Block A'),
(6, '2023-12-10', 'The teacher explained the concepts clearly and effectively.', 4, 5, 4, 'Manfredo Marcellano', 12345, 'Understanding The Self', 'John Doe', 'Block A'),
(10, '2024-12-11', 'Ms. Rosalie Catu is a very good teacher.', 5, 4, 3, 'Rosalie Catu', 0, 'Understanding The Self', 'Leika Mae Delfin', 'Block A');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `Id` int(11) NOT NULL,
  `UserId` varchar(255) NOT NULL,
  `ImgURL` varchar(255) DEFAULT NULL,
  `Fname` varchar(255) NOT NULL,
  `Lname` varchar(255) NOT NULL,
  `Gender` varchar(50) DEFAULT NULL,
  `Address` text DEFAULT NULL,
  `Phone` varchar(50) DEFAULT NULL,
  `EmailAddress` varchar(255) DEFAULT NULL,
  `Password` varchar(255) NOT NULL,
  `Role` varchar(50) DEFAULT NULL,
  `Course` varchar(255) DEFAULT NULL,
  `YearLevel` int(2) DEFAULT NULL,
  `Block` varchar(50) DEFAULT NULL,
  `CreatedAt` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`Id`, `UserId`, `ImgURL`, `Fname`, `Lname`, `Gender`, `Address`, `Phone`, `EmailAddress`, `Password`, `Role`, `Course`, `YearLevel`, `Block`, `CreatedAt`) VALUES
(1, 'admin001', NULL, 'Cristian', 'Gabutin', 'Male', NULL, '1234567890', 'admin@adminconnect.com', '12345', 'Admin', NULL, NULL, NULL, '2024-12-10 00:21:53'),
(2, 'student001', NULL, 'Leika Mae', 'Delfin', 'Female', NULL, '9876543210', 'student@adminconnect.com', '12345', 'Student', 'Bachelor of Science', 2, 'Block A', '2024-12-10 00:21:53');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `announcements`
--
ALTER TABLE `announcements`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `evaluation`
--
ALTER TABLE `evaluation`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`Id`),
  ADD UNIQUE KEY `UserId` (`UserId`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `announcements`
--
ALTER TABLE `announcements`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `evaluation`
--
ALTER TABLE `evaluation`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
