const welcomeEmailTemplate = (sendTo, subject) => {
    return `
      <!DOCTYPE html>
      <html lang="en">
      <head>
          <meta charset="UTF-8">
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
          <title>${subject} - Urgent Notice</title>
      </head>
      <body>
          <h1>Verify Your Email</h1>
          <p>Hello,</p>
          <p>Thank you for registering. Please verify your email by clicking the link below:</p>
          <a href="${sendTo}">Verify Email</a>
          <p>If you did not sign up for this account, you can safely ignore this email.</p>
          <p>This email expires after 15 mins</p>
          <p>Thank you!</p>
      </body>
      </html>
    `;
  };

  
  export const emailTemplates = {
    welcomeEmailTemplate
  };