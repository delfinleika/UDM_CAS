import express from 'express';
import db from './config/database.js';
import bodyParser from 'body-parser';
import cors from 'cors';
import dotenv from 'dotenv';
import routes from './config/routes.js'

const app = express();

// Middleware for JSON and form data parsing
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
dotenv.config();

//cors
app.use(cors({
    origin: 'http://localhost:3000', 
    methods: 'GET, POST, PUT, DELETE'
}));

//routes
app.use(routes);

// Global error handler
app.use((err, req, res, next) => {
    console.error(err); // Log the error for debugging
    res.status(err.status || 500).send("Something went wrong!");
    res.json({
        error: {
            message: error.message 
        }
    });
});

// Test database connection and start the server
db.query("SELECT * FROM user WHERE Id = 1")
.then(() => {
    console.log('Db connection succeeded');
    app.listen(3001, () => console.log('Server started at 3001'));
})
.catch(error => {
    console.error("Db connection error:\n", error);
});
