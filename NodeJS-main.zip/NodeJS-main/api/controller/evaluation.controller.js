import express from 'express';
import { service } from '../services/evaluations.service.js';  // Ensure the correct import path

const evaluateRouter = express.Router();

// Get all evaluations
evaluateRouter.get('/', async (req, res) => {
    try {
        const evaluations = await service.getAllEvaluations();
        res.json(evaluations);  // Send the list of evaluations
    } catch (error) {
        console.error('Error fetching evaluations:', error);
        res.status(500).json({ error: 'Failed to retrieve evaluations' });
    }
});

// Get an evaluation by ID
evaluateRouter.get('/:id', async (req, res) => {
    const { id } = req.params;
    try {
        const evaluation = await service.getEvaluationById(id);
        res.json(evaluation);  // Send the evaluation data
    } catch (error) {
        console.error(`Error fetching evaluation with ID ${id}:`, error);
        res.status(404).json({ error: `Evaluation with ID ${id} not found` });
    }
});

// Create a new evaluation
evaluateRouter.post('/sendEvaluation', async (req, res) => {
    try {
        const evaluationData = req.body;
        const result = await service.createEvaluation(evaluationData);
        res.status(201).json(result);  // Send back the created evaluation
    } catch (error) {
        console.error('Error creating evaluation:', error);
        res.status(500).json({ error: 'Failed to create evaluation' });
    }
});

// Update an evaluation by ID
evaluateRouter.put('/:id', async (req, res) => {
    const { id } = req.params;
    const evaluationData = req.body;
    try {
        const updatedEvaluation = await service.updateEvaluation(id, evaluationData);
        res.json(updatedEvaluation);  // Send the updated evaluation data
    } catch (error) {
        console.error(`Error updating evaluation with ID ${id}:`, error);
        res.status(500).json({ error: `Failed to update evaluation with ID ${id}` });
    }
});

// Delete an evaluation by ID
evaluateRouter.delete('/:id', async (req, res) => {
    const { id } = req.params;
    try {
        const result = await service.deleteEvaluationById(id);
        res.json(result);  // Send the success message
    } catch (error) {
        console.error(`Error deleting evaluation with ID ${id}:`, error);
        res.status(500).json({ error: `Failed to delete evaluation with ID ${id}` });
    }
});

export default evaluateRouter;
