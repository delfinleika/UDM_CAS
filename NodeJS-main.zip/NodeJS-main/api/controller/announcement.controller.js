import express from 'express';
import { announcementService } from '../services/announcements.service.js';

const announcementRouter = express.Router();

// Get all announcements
announcementRouter.get('/', async (req, res) => {
  try {
    const announcements = await announcementService.getAllAnnouncements();
    res.json(announcements);
  } catch (error) {
    console.error('Error fetching announcements:', error);
    res.status(500).json({ error: 'Failed to retrieve announcements' });
  }
});

// Get announcement by ID
announcementRouter.get('/:id', async (req, res) => {
  const { id } = req.params;
  try {
    const announcement = await announcementService.getAnnouncementById(id);
    res.json(announcement);
  } catch (error) {
    console.error(`Error fetching announcement with ID ${id}:`, error);
    res.status(404).json({ error: `Announcement with ID ${id} not found` });
  }
});

// Create a new announcement
announcementRouter.post('/sendAnnouncement', async (req, res) => {
  try {
    const announcementData = req.body;
    const result = await announcementService.createAnnouncement(announcementData);
    res.status(201).json(result); // Return the created announcement
  } catch (error) {
    console.error('Error creating announcement:', error);
    res.status(500).json({ error: 'Failed to create announcement' });
  }
});

// Update an announcement by ID
announcementRouter.put('/:id', async (req, res) => {
  const { id } = req.params;
  const announcementData = req.body;
  try {
    const updatedAnnouncement = await announcementService.updateAnnouncement(id, announcementData);
    res.json(updatedAnnouncement);
  } catch (error) {
    console.error(`Error updating announcement with ID ${id}:`, error);
    res.status(500).json({ error: `Failed to update announcement with ID ${id}` });
  }
});

// Delete an announcement by ID
announcementRouter.delete('/:id', async (req, res) => {
  const { id } = req.params;
  try {
    const result = await announcementService.deleteAnnouncementById(id);
    res.json(result); // Send the success message
  } catch (error) {
    console.error(`Error deleting announcement with ID ${id}:`, error);
    res.status(500).json({ error: `Failed to delete announcement with ID ${id}` });
  }
});

export default announcementRouter;
