import express from 'express'
import { service } from '../services/users.service.js';

    const userRouter = express.Router();

    userRouter.get('/', async (req, res) => {
        const employees = await service.getAllUsers();
        res.send(employees)
    })

    userRouter.get('/:id', async (req, res) => {
        const employees = await service.getEmployeeById(req.params.id);
        res.send(employees)
    })

    userRouter.delete('/:id', async (req, res) => {
        const employees = await service.deleteEmployeeById(req.params.id);
        res.send("Deleted succesfully")
    })

    userRouter.post('/', async (req, res) => {
        const employeeData = req.body;
        const newEmployee = await service.createEmployee(employeeData);
        res.status(201).send(newEmployee);
    });

    userRouter.put('/:id', async (req, res) => {
        const employeeData = req.body;
        const updatedEmployee = await service.updateEmployee(req.params.id, employeeData);
        res.send(updatedEmployee); 
    });

    userRouter.post('/login/', async (req, res) => {
        const employeeData = req.body;
        const employees = await service.loginEmployee(employeeData);
        res.send(employees)
    })

    userRouter.post('/loginJWT/', async (req, res) => {
        const employeeData = req.body;
        const employees = await service.loginUserJWT(req, res);
        res.send(employees)
    })
    
    userRouter.post('/sendEmailToUser', async (req, res) => {
        try {
          const result = await service.sendEmail("gerezjungie393@gmail.com", "subject", "test output");
          res.send(result.envelope);
        } catch (error) {
          res.status(500);
        }
      });
 

export default userRouter;