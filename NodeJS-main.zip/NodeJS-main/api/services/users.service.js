import db from '../../config/database.js';
import jwt from 'jsonwebtoken';
import transporter from '../../config/transporter.js';
import { emailTemplates } from '../../helpers/email_templates/welcome.js';

async function getAllUsers() {
    const [rows] = await db.query("SELECT * FROM user");
    return rows; 
}

async function getEmployeeById(id) {
    const [rows] = await db.query("SELECT * FROM user WHERE Id = ?", [id]);    
    return rows; 
}

async function deleteEmployeeById(id) {
    const [rows] = await db.query("DELETE FROM user WHERE Id = ?", [id]);    
    return rows; 
}

async function createEmployee(employeeData) {
  const {
    UserId,
    ImgURL,
    Fname,
    Lname,
    Address,
    Phone,
    EmailAddress,
    Password,
    Role,
    Course,
    YearLevel,
    Block
  } = employeeData;

  const result = await db.query(
    `INSERT INTO user 
     (UserId, Fname, Lname, Address, Phone, EmailAddress, Password, Role, Course, YearLevel, Block) 
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    [UserId, Fname, Lname, Address, Phone, EmailAddress, Password, Role, Course, YearLevel, Block]
  );

  return { id: result[0].insertId, ...employeeData };
}

async function updateEmployee(id, employeeData) {
    const { Id, Fname, Lname } = employeeData;
    await db.query("UPDATE user SET Fname = ?, Lname = ? WHERE Id = ?", [Fname, Lname, Id]);
    return { id, Fname, Lname }; // Return the updated employee's details
}

async function loginEmployee(employeeData) {
    const { Fname, Lname } = employeeData;
    const [rows] = await db.query("SELECT * FROM user WHERE Fname = ? AND Lname = ?", [Fname, Lname]);    
    if (rows.length > 0) {
        return true; 
    }
    return false; 
}


async function loginUserJWT(req) {
  try {
      const { EmailAddress, Password } = req.body;

      // Validate inputs
      if (!EmailAddress || !Password) {
          return { status: 401, message: 'Email address and password are required.' };
      }

      // Query the database
      const [resultUser] = await db.query(
          "SELECT * FROM user WHERE EmailAddress = ? AND Password = ?",
          [EmailAddress, Password]
      );

      if (!resultUser || resultUser.length === 0) {
          return { status: 401, message: 'Invalid username or password.' };
      }

      const user = resultUser[0];

      return {
              UserId: user.Id,
              Fname: user.Fname,
              Lname: user.Lname,
              Role: user.Role,
              YearLevel: user.YearLevel,
              Block: user.Block
      };
      
  } catch (error) {
      console.error('Error in loginUserJWT:', error);
      return { status: 500, message: 'An error occurred during login.' };
  }
}

export async function sendEmail(sendTo, subject, text) {

    const output = emailTemplates.welcomeEmailTemplate(sendTo, subject);

    const mailOptions = {
      from: { name: 'Jungie Gerez', address: process.env.EMAIL_USER }, 
      to: sendTo, 
      subject: subject, 
      text: text, 
      html: output, 
    };

    try {
      const info = await transporter.sendMail(mailOptions);
    //   console.log("Email sent successfully:", info);
      return info;
    } catch (error) {
      console.error("Error while sending email:", error);
      throw error; // Rethrow the error for the caller to handle
    }
  }

  
  async function evaluateTeacher(evaluationData) {
    const { 
      student_id, 
      evaluation_date, 
      feedback, 
      performance_rating, 
      communication_rating, 
      ethics_rating, 
      teacher_name, 
      subject, 
      student_name, 
      block 
    } = evaluationData; 
  
    try {
      const result = await db.query(
        `INSERT INTO evaluation (
          student_id, 
          evaluation_date, 
          feedback, 
          performance_rating, 
          communication_rating, 
          ethics_rating, 
          teacher_name, 
          subject, 
          student_name, 
          block
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`, 
        [
          student_id, 
          evaluation_date, 
          feedback, 
          performance_rating, 
          communication_rating, 
          ethics_rating, 
          teacher_name, 
          subject, 
          student_name, 
          block,
        ]
      );
  
      return { 
        id: result[0].insertId, 
        student_id, 
        evaluation_date, 
        feedback, 
        performance_rating, 
        communication_rating, 
        ethics_rating, 
        teacher_name, 
        subject, 
        student_name, 
        block,
      };
    } catch (error) {
      console.error('Error inserting evaluation:', error);
      throw error;
    }
  }

  async function getAllEvaluation() {
    const [rows] = await db.query("SELECT * FROM evaluation");
    return rows; 
}

  

export const service = {
    getAllUsers,
    getEmployeeById,
    deleteEmployeeById,
    createEmployee,
    updateEmployee,
    loginEmployee, 
    loginUserJWT,
    sendEmail,
    evaluateTeacher,
    getAllEvaluation
};