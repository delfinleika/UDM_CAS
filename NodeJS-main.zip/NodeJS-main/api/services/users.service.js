import db from '../../config/database.js';
import jwt from 'jsonwebtoken';
import transporter from '../../config/transporter.js';
import { emailTemplates } from '../../helpers/email_templates/welcome.js';

async function getAllUsers() {
    const [rows] = await db.query("SELECT * FROM user");
    return rows; 
}

async function getEmployeeById(id) {
    const [rows] = await db.query("SELECT * FROM user WHERE Id = ?", [id]);    
    return rows; 
}

async function deleteEmployeeById(id) {
    const [rows] = await db.query("DELETE FROM user WHERE Id = ?", [id]);    
    return rows; 
}

async function createEmployee(employeeData) {
  const {
    UserId,
    ImgURL,
    Fname,
    Lname,
    Address,
    Phone,
    EmailAddress,
    Password,
    Role,
    Course,
    YearLevel,
    Block
  } = employeeData;

  const result = await db.query(
    `INSERT INTO user 
     (UserId, Fname, Lname, Address, Phone, EmailAddress, Password, Role, Course, YearLevel, Block) 
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    [UserId, Fname, Lname, Address, Phone, EmailAddress, Password, Role, Course, YearLevel, Block]
  );

  return { id: result[0].insertId, ...employeeData };
}

async function updateEmployee(id, employeeData) {
    const { Id, Fname, Lname } = employeeData;
    await db.query("UPDATE user SET Fname = ?, Lname = ? WHERE Id = ?", [Fname, Lname, Id]);
    return { id, Fname, Lname }; // Return the updated employee's details
}

async function loginEmployee(employeeData) {
    const { Fname, Lname } = employeeData;
    const [rows] = await db.query("SELECT * FROM user WHERE Fname = ? AND Lname = ?", [Fname, Lname]);    
    if (rows.length > 0) {
        return true; 
    }
    return false; 
}

async function loginUserJWT(req, res) {
    try {
        const { EmailAddress, Password } = req.body;

        if (!EmailAddress && !Password) {
          return res.status(401).json({ message: 'Invalid username or password.' });
      }

        const [resultUser] = await db.query("SELECT * FROM user WHERE EmailAddress = ? AND Password = ?", [EmailAddress, Password]);

        if (!resultUser[0]) {
            return res.status(401).json({ message: 'No user found.' });
        }

        // Generate JWT token
        const token = jwt.sign(
            { userId: resultUser.Id, role: resultUser.Role }, // Payload
            process.env.JWT_SECRET,               // Secret key from environment variables
            { expiresIn: '1h' }                   // Token expiration time
        );

        res.cookie('auth_token', token, {
            httpOnly: true, 
            secure: process.env.NODE_ENV === 'production', 
            maxAge: 1000 * 60 * 60,  // Cookie expiration (e.g., 1 hr)
            sameSite: 'strict'  // Prevents the cookie from being sent in cross-site requests
        });

        res.status(200).json({
            message: 'Login successful.',
            token,
            user: resultUser.map(({ UserId, Fname, Lname, Role, YearLevel, Block }) => ({ UserId, Fname, Lname, Role, YearLevel, Block }))
        });

    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'An error occurred during login.' });
    }
}

export async function sendEmail(sendTo, subject, text) {

    const output = emailTemplates.welcomeEmailTemplate(sendTo, subject);

    const mailOptions = {
      from: { name: 'Jungie Gerez', address: process.env.EMAIL_USER }, 
      to: sendTo, 
      subject: subject, 
      text: text, 
      html: output, 
    };

    try {
      const info = await transporter.sendMail(mailOptions);
    //   console.log("Email sent successfully:", info);
      return info;
    } catch (error) {
      console.error("Error while sending email:", error);
      throw error; // Rethrow the error for the caller to handle
    }
  }

  
  async function evaluateTeacher(evaluationData) {
    const { 
      student_id, 
      evaluation_date, 
      feedback, 
      performance_rating, 
      communication_rating, 
      ethics_rating, 
      teacher_name, 
      subject, 
      student_name, 
      block 
    } = evaluationData; 
  
    try {
      const result = await db.query(
        `INSERT INTO evaluation (
          student_id, 
          evaluation_date, 
          feedback, 
          performance_rating, 
          communication_rating, 
          ethics_rating, 
          teacher_name, 
          subject, 
          student_name, 
          block
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`, 
        [
          student_id, 
          evaluation_date, 
          feedback, 
          performance_rating, 
          communication_rating, 
          ethics_rating, 
          teacher_name, 
          subject, 
          student_name, 
          block,
        ]
      );
  
      return { 
        id: result[0].insertId, 
        student_id, 
        evaluation_date, 
        feedback, 
        performance_rating, 
        communication_rating, 
        ethics_rating, 
        teacher_name, 
        subject, 
        student_name, 
        block,
      };
    } catch (error) {
      console.error('Error inserting evaluation:', error);
      throw error;
    }
  }

  async function getAllEvaluation() {
    const [rows] = await db.query("SELECT * FROM evaluation");
    return rows; 
}

  

export const service = {
    getAllUsers,
    getEmployeeById,
    deleteEmployeeById,
    createEmployee,
    updateEmployee,
    loginEmployee, 
    loginUserJWT,
    sendEmail,
    evaluateTeacher,
    getAllEvaluation
};