import db from '../../config/database.js';

// Create Evaluation
async function createEvaluation(evaluationData) {
  const { 
      student_id, 
      evaluation_date, 
      feedback, 
      performance_rating, 
      communication_rating, 
      ethics_rating, 
      teacher_name, 
      subject, 
      student_name, 
      block 
  } = evaluationData;

  try {
      const result = await db.query(
          `INSERT INTO evaluation (
              student_id, 
              evaluation_date, 
              feedback, 
              performance_rating, 
              communication_rating, 
              ethics_rating, 
              teacher_name, 
              subject, 
              student_name, 
              block
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`, 
          [
              student_id, 
              evaluation_date, 
              feedback, 
              performance_rating, 
              communication_rating, 
              ethics_rating, 
              teacher_name, 
              subject, 
              student_name, 
              block,
          ]
      );

      return { 
          id: result[0].insertId, 
          student_id, 
          evaluation_date, 
          feedback, 
          performance_rating, 
          communication_rating, 
          ethics_rating, 
          teacher_name, 
          subject, 
          student_name, 
          block,
      };
  } catch (error) {
      console.error('Error inserting evaluation:', error);
      throw error;
  }
}

// Get All Evaluations
async function getAllEvaluations() {
  const [rows] = await db.query("SELECT * FROM evaluation");
  return rows;
}

// Get Evaluation by ID
async function getEvaluationById(id) {
  const [rows] = await db.query("SELECT * FROM evaluation WHERE id = ?", [id]);
  if (rows.length > 0) {
      return rows[0];
  } else {
      throw new Error(`Evaluation with ID ${id} not found`);
  }
}

// Update Evaluation by ID
async function updateEvaluation(id, evaluationData) {
  const {
      student_id, 
      evaluation_date, 
      feedback, 
      performance_rating, 
      communication_rating, 
      ethics_rating, 
      teacher_name, 
      subject, 
      student_name, 
      block 
  } = evaluationData;

  try {
      const result = await db.query(
          `UPDATE evaluation SET 
              student_id = ?, 
              evaluation_date = ?, 
              feedback = ?, 
              performance_rating = ?, 
              communication_rating = ?, 
              ethics_rating = ?, 
              teacher_name = ?, 
              subject = ?, 
              student_name = ?, 
              block = ? 
          WHERE id = ?`, 
          [
              student_id, 
              evaluation_date, 
              feedback, 
              performance_rating, 
              communication_rating, 
              ethics_rating, 
              teacher_name, 
              subject, 
              student_name, 
              block, 
              id
          ]
      );

      if (result[0].affectedRows > 0) {
          return { id, student_id, evaluation_date, feedback, performance_rating, communication_rating, ethics_rating, teacher_name, subject, student_name, block };
      } else {
          throw new Error(`Evaluation with ID ${id} not found`);
      }
  } catch (error) {
      console.error('Error updating evaluation:', error);
      throw error;
  }
}

// Delete Evaluation by ID
async function deleteEvaluationById(id) {
  try {
      const result = await db.query("DELETE FROM evaluation WHERE id = ?", [id]);
      if (result[0].affectedRows > 0) {
          return { message: `Evaluation with ID ${id} has been deleted` };
      } else {
          throw new Error(`Evaluation with ID ${id} not found`);
      }
  } catch (error) {
      console.error('Error deleting evaluation:', error);
      throw error;
  }
}

export const service = {
  createEvaluation,
  getAllEvaluations,
  getEvaluationById,
  updateEvaluation,
  deleteEvaluationById
};
