import db from '../../config/database.js';

// Create Announcement
async function createAnnouncement(announcementData) {
  const { title, content, date, author } = announcementData;

  try {
    const result = await db.query(
      `INSERT INTO announcements (
        title, 
        content, 
        date, 
        author
      ) VALUES (?, ?, ?, ?)`,
      [title, content, date, author]
    );

    return {
      id: result[0].insertId,
      title,
      content,
      date,
      author
    };
  } catch (error) {
    console.error('Error inserting announcement:', error);
    throw error;
  }
}

// Get All Announcements
async function getAllAnnouncements() {
  const [rows] = await db.query("SELECT * FROM announcements");
  return rows;
}

// Get Announcement by ID
async function getAnnouncementById(id) {
  const [rows] = await db.query("SELECT * FROM announcements WHERE id = ?", [id]);
  if (rows.length > 0) {
    return rows[0];
  } else {
    throw new Error(`Announcement with ID ${id} not found`);
  }
}

// Update Announcement by ID
async function updateAnnouncement(id, announcementData) {
  const { title, content, date, author } = announcementData;

  try {
    const result = await db.query(
      `UPDATE announcements SET 
        title = ?, 
        content = ?, 
        date = ?, 
        author = ? 
      WHERE id = ?`,
      [title, content, date, author, id]
    );

    if (result[0].affectedRows > 0) {
      return { id, title, content, date, author };
    } else {
      throw new Error(`Announcement with ID ${id} not found`);
    }
  } catch (error) {
    console.error('Error updating announcement:', error);
    throw error;
  }
}

// Delete Announcement by ID
async function deleteAnnouncementById(id) {
  try {
    const result = await db.query("DELETE FROM announcements WHERE id = ?", [id]);
    if (result[0].affectedRows > 0) {
      return { message: `Announcement with ID ${id} has been deleted` };
    } else {
      throw new Error(`Announcement with ID ${id} not found`);
    }
  } catch (error) {
    console.error('Error deleting announcement:', error);
    throw error;
  }
}

export const announcementService = {
  createAnnouncement,
  getAllAnnouncements,
  getAnnouncementById,
  updateAnnouncement,
  deleteAnnouncementById
};
