// const bcrypt = require('bcrypt');

class ValidationError extends Error {
    constructor(message) {
        super(message);
        this.name = "ValidationError";
    }
}

class User {
    constructor(id, name, email, password, contact, pending_email, role = 'User', verified, deleted_at = null) {
        if (!name || !email || !password || !contact) {
            throw new ValidationError('All fields are required');
        }
        if (!User.validateName(name)) {
            throw new ValidationError('Name must be a string and at least 3 characters long');
        }
        if (!User.validateEmail(email)) {
            throw new ValidationError('Email is not valid');
        }
        if (!User.validateContact(contact)) {
            throw new ValidationError('Contact must start with 0 or +63');
        }
        if (!['User', 'Admin'].includes(role)) {
            throw new ValidationError('Invalid role');
        }

        this.id = id;
        this.name = name;
        this.email = email;
        this.password = password;
        this.contact = contact;
        this.pending_email = pending_email;
        this.role = role;
        this.verified = verified;
        this.deleted_at = deleted_at;
    }

    static validateName(name) {
        return typeof name === 'string' && name.length >= 3;
    }

    static validateEmail(email) {
        const re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
        return re.test(String(email).toLowerCase());
    }

    static validateContact(contact) {
        const re = /^(0|\+63)9\d{9}$/;
        return re.test(contact);
    }
}

export const UserModel = {
   User, ValidationError
};

// module.exports = {User, ValidationError};