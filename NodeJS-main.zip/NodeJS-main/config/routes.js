import express from 'express';
import userRouter from '../api/controller/user.controller.js';
import evaluateRouter from '../api/controller/evaluation.controller.js';
import announcementRouter from '../api/controller/announcement.controller.js';

const app = express();

// Register the employee router
app.use('/users', userRouter);
app.use('/evaluation', evaluateRouter);
app.use('/announcement', announcementRouter);

export default app;