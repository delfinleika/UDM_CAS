import dotenv from 'dotenv';
import nodemailer from 'nodemailer';

// Load .env file
dotenv.config();

// Nodemailer Configuration with Google SMTP
const transporter = nodemailer.createTransport({
  service: 'gmail',
  host: 'smtp.gmail.com',
  port: 465,
  secure: true, // Port 465 requires secure: true
  auth: {
    user: process.env.EMAIL_USER, 
    pass: process.env.EMAIL_PASSWORD, 
  },
});

// Verify transporter configuration
// transporter.verify(function (error, success) {
//   if (error) {
//     console.error("Transporter configuration error:", error);
//   } else {
//     console.log("Transporter is ready to send emails");
//   }
// });


export default transporter;